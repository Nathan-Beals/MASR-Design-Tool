import os

# This holds the location of the database folder with respect to the driver file in the root directory
db_location = os.path.dirname(os.path.abspath(__file__)) + '/databases/'