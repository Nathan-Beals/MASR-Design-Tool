#! /usr/bin/env python

import masr_design_tool.main_GUI


def main():
    masr_design_tool.main_GUI.main()

if __name__ == "__main__":
    main()