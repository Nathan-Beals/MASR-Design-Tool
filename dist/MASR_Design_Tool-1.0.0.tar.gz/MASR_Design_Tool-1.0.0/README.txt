This is the ARL-Georgia Tech Python MASR tool.

- For instructions on how to run the main
script see INSTALL.txt.

- For a high-level overview of the application see 'docs/High-Level
Overview of Python MASR App.pdf'.

- For a more detailed description of the alternatives generation process see 'docs/
Outline of Alternatives Generation Process.pdf'.